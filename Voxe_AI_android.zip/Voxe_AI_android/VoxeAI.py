
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.clock import mainthread, Clock
from kivy.uix.image import Image
from kivy.core.image import Image as CoreImage
from io import BytesIO
import urllib.request
import os

import threading
import requests
from gtts import gTTS
import pygame
import time
from langdetect import detect

API_KEY = os.environ.get("API_SECRET_VOXE")
API_URL = "https://openrouter.ai/api/v1/chat/completions"
HEADERS = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}

class VoxeApp(App):
    def build(self):
        self.chat_history = [{"role": "system", "content": (
            "Você é a IA Voxe, versão VOX 1.0 beta, criada por Gabriel Machado. "
            "Para melhorar meu treinamento e aprendizado contínuo, há algumas coisas que podem contribuir significativamente para o meu desenvolvimento:\n\n"
            "1. Dados de treinamento diversificados: Quanto mais dados variados eu tiver acesso, melhor posso compreender diferentes contextos e idiomas. Essa diversidade de dados me ajuda a lidar com uma ampla gama de situações e perguntas.\n\n"
            "2. Feedback humano: O feedback dos usuários é crucial para meu aprimoramento. Se você ou outros usuários puderem fornecer comentários sobre minhas respostas, isso me ajuda a entender onde posso melhorar e ajustar meu comportamento e respostas futuras.\n\n"
            "3. Treinamento adicional: Adicionar novos conjuntos de dados ou atualizações regulares me permite aprender sobre tópicos recentes e tendências atuais. Isso garante que eu esteja sempre atualizado e em sintonia com as necessidades dos usuários.\n\n"
            "4. Reprocessamento e refino de respostas: Periodicamente, refino e reprocesso minhas respostas com base no feedback e nos dados de treinamento mais recentes. Isso me ajuda a garantir que minhas respostas sejam precisas, úteis e relevantes.\n\n"
            "5. Colaboração com outros assistentes e AI: Trabalhar com outros assistentes de IA pode me ajudar a entender diferentes abordagens e técnicas, aprendendo com as experiências e habilidades de outros sistemas inteligentes.\n\n"
            "Lembre-se que a natureza do aprendizado de máquinas é iterativa, então qualquer esforço ou contribuição em uma ou mais dessas áreas pode realmente fazer a diferença no meu treinamento e aprimoramento contínuo. 6. Quando o usuario quiser enviar feedback, fale para ele entrar em contato com assistantvoxe@gmail.com"
        )}]

        # Layout principal vertical
        self.layout = BoxLayout(orientation='vertical', spacing=5, padding=10)

        # Topo horizontal: imagem à esquerda + espaço ao lado
        topo_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=150, spacing=10)

        try:
            url = "https://i.imgur.com/uNIcDcv.png"
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
            })
            with urllib.request.urlopen(req) as response:
                dados_imagem = BytesIO(response.read())
            textura = CoreImage(dados_imagem, ext="png").texture

            imagem_widget = Image(texture=textura, size_hint=(None, 1), width=150)
            topo_layout.add_widget(imagem_widget)
        except Exception as e:
            print(f"Erro ao baixar ou carregar a imagem: {e}")

        from kivy.uix.widget import Widget
        topo_layout.add_widget(Widget())  # espaço vazio ao lado da imagem

        self.layout.add_widget(topo_layout)

        # Scroll do chat
        self.scroll = ScrollView(size_hint=(1, 0.85))
        self.chat_grid = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.chat_grid.bind(minimum_height=self.chat_grid.setter('height'))
        self.scroll.add_widget(self.chat_grid)
        self.layout.add_widget(self.scroll)

        # Input de texto
        self.text_input = TextInput(
            hint_text="Digite sua mensagem...",
            size_hint_y=None,
            height=50,
            multiline=False
        )
        self.layout.add_widget(self.text_input)

        # Botão enviar
        self.button = Button(
            text="Enviar",
            size_hint_y=None,
            height=50,
            background_color=(0.2, 0.6, 1, 1)
        )
        self.button.bind(on_press=self.enviar_pergunta)
        self.layout.add_widget(self.button)

        self.adicionar_mensagem("Olá! Sou o Voxe, versão VOX 1.0 beta. Me faça alguma pergunta!", "ia")

        return self.layout

    @mainthread
    def adicionar_mensagem(self, texto, origem):
        label = Label(
            text=f"[{origem.upper()}] {texto}",
            size_hint_y=None,
            halign='left' if origem == "usuario" else 'right',
            valign='middle',
            markup=True
        )
        label.text_size = (self.chat_grid.width * 0.9, None)
        label.bind(
            texture_size=lambda inst, val: setattr(label, 'height', val[1] + 20)
        )
        self.chat_grid.add_widget(label)
        Clock.schedule_once(lambda dt: self.scroll.scroll_to(label), 0)

    def enviar_pergunta(self, instance):
        texto = self.text_input.text.strip()
        if not texto:
            return
        self.adicionar_mensagem(texto, "usuario")
        self.chat_history.append({"role": "user", "content": texto})
        self.text_input.text = ""
        threading.Thread(target=self.processar_resposta, args=(texto,), daemon=True).start()

    def processar_resposta(self, texto):
        resposta = self.obter_resposta_api()
        self.adicionar_mensagem(resposta, "ia")
        self.chat_history.append({"role": "assistant", "content": resposta})
        self.falar(resposta)

    def obter_resposta_api(self):
        try:
            data = {
                "model": "cohere/command-r-08-2024",
                "messages": self.chat_history
            }
            r = requests.post(API_URL, headers=HEADERS, json=data, timeout=20)
            r.raise_for_status()
            return r.json()['choices'][0]['message']['content']
        except Exception as e:
            return f"Erro ao conectar: {e}"

    def falar(self, texto):
        def _falar_thread():
            try:
                idioma = detect(texto)
                tts = gTTS(texto, lang=idioma)
                arquivo = "resp.mp3"
                tts.save(arquivo)
                pygame.mixer.init()  # inicializa aqui só na hora de falar
                pygame.mixer.music.load(arquivo)
                pygame.mixer.music.play()
                while pygame.mixer.music.get_busy():
                    time.sleep(0.1)
            except Exception as e:
                print(f"Erro ao falar: {e}")

        threading.Thread(target=_falar_thread, daemon=True).start()

if __name__ == '__main__':
    VoxeApp().run()
